package com.iweb.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * @author jxy
 * @date
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Product {
    private int pid;
    private String pName;
    private double originalPrice;
    private Category category;
    private int stock;
    private Date createDate;
    private double promotePrice;
    private String subTitle;
}
