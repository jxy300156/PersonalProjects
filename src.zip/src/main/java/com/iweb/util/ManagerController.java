package com.iweb.util;

import com.iweb.pojo.*;
import com.iweb.pool.ConnectionPool;
import com.sun.org.apache.xpath.internal.operations.Or;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * @author jxy
 * @date
 */
public class ManagerController {
    private static final int CORE_THREADS =20;
    private static final int CONNECTIONS = 20;
    private ConnectionPool connectionPool;
    private ThreadPoolExecutor threadPool;
    public ManagerController(){
        connectionPool = new ConnectionPool(CONNECTIONS);
        threadPool = new ThreadPoolExecutor(CORE_THREADS,25,60, TimeUnit.SECONDS,
                new LinkedBlockingDeque<Runnable>());
    }
    public void addCategory(Category c){
        if(c==null||c.getCname()==null||c.getCname().equals("")){
            System.out.println("参数有误！");
            return;
        }
        String sql = "insert into shop.catagory(name) values (?)";
        try(
                Connection connection = connectionPool.getConnection();
                PreparedStatement ps = connection.prepareStatement(sql)){
            ps.setString(1,c.getCname());
            ps.execute();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public void changeCategory(Category c){
        if(c==null||c.getCname()==null||c.getCname().equals("")){
            System.out.println("参数有误！");
            return;
        }
        String sql = "update shop.catagory set name = ? where id = ?";
        try(
                Connection connection = connectionPool.getConnection();
                PreparedStatement ps = connection.prepareStatement(sql)){
            ps.setString(1,c.getCname());
            ps.setInt(2,c.getCid());
            ps.execute();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public void deleteCategory(Category c){
        if(c==null||c.getCname()==null||c.getCname().equals("")){
            System.out.println("参数有误！");
            return;
        }
        String sql = "delete from shop.catagory where id = ?";
        try(
                Connection connection = connectionPool.getConnection();
                PreparedStatement ps = connection.prepareStatement(sql)){
            ps.setInt(1,c.getCid());
            ps.execute();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public void addProduct(Product p){
        if(p==null||p.getPName()==null||p.getPName().equals("")){
            System.out.println("参数有误！");
            return;
        }
        String sql = "insert into shop.product(name,originalprice,cid,stock,createDate," +
                "promoteprice,subtitle) values (?,?,?,?,?,?,?)";
        try(
                Connection connection = connectionPool.getConnection();
                PreparedStatement ps = connection.prepareStatement(sql)){
            ps.setString(1,p.getPName());
            ps.setDouble(2,p.getOriginalPrice());
            ps.setInt(3,p.getCategory().getCid());
            ps.setInt(4,p.getStock());
            ps.setDate(5, (Date) p.getCreateDate());
            ps.setDouble(6,p.getPromotePrice());
            ps.setString(7,p.getSubTitle());
            ps.execute();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public void changeProduct(Product p){
        if(p==null||p.getPName()==null||p.getPName().equals("")){
            System.out.println("参数有误！");
            return;
        }
        String sql = "update shop.product set name=?,originalprice=?,stock=?," +
                "createDate=?,promoteprice=?,subtitle=? where id = ?,cid=?";
        try(
                Connection connection = connectionPool.getConnection();
                PreparedStatement ps = connection.prepareStatement(sql)){
            ps.setString(1,p.getPName());
            ps.setDouble(2,p.getOriginalPrice());

            ps.setInt(3,p.getStock());
            ps.setDate(4, (Date) p.getCreateDate());
            ps.setDouble(5,p.getPromotePrice());
            ps.setString(6,p.getSubTitle());
            ps.setInt(7,p.getPid());
            ps.setInt(8,p.getCategory().getCid());
            ps.execute();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public void deleteProduct(Product p){
        if(p==null||p.getPName()==null||p.getPName().equals("")){
            System.out.println("参数有误！");
            return;
        }
        String sql = "delete from shop.product where id = ?";
        try(
                Connection connection = connectionPool.getConnection();
                PreparedStatement ps = connection.prepareStatement(sql)){
            ps.setInt(1,p.getPid());
            ps.execute();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void addProperty(Property pro){
        if(pro==null||pro.getProName()==null||pro.getProName().equals("")){
            System.out.println("参数有误！");
            return;
        }
        String sql = "insert into shop.property(cid,name) values (?,?)";
        try(
                Connection connection = connectionPool.getConnection();
                PreparedStatement ps = connection.prepareStatement(sql)){
            ps.setInt(1,pro.getCategory().getCid());
            ps.setString(2,pro.getProName());
            ps.execute();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public void changeProperty(Property pro){
        if(pro==null||pro.getProName()==null||pro.getProName().equals("")){
            System.out.println("参数有误！");
            return;
        }
        String sql = "update shop.property set cid=?,name=? where id = ?";
        try(
                Connection connection = connectionPool.getConnection();
                PreparedStatement ps = connection.prepareStatement(sql)){
            ps.setInt(1,pro.getCategory().getCid());
            ps.setString(2,pro.getProName());
            ps.setInt(3,pro.getProId());
            ps.execute();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public void deleteProperty(Property pro){
        if(pro==null||pro.getProName()==null||pro.getProName().equals("")){
            System.out.println("参数有误！");
            return;
        }
        String sql = "delete from shop.product where id = ?";
        try(
                Connection connection = connectionPool.getConnection();
                PreparedStatement ps = connection.prepareStatement(sql)){
            ps.setInt(1,pro.getProId());
            ps.execute();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public void addPropertyValue(PropertyValue pv){
        if(pv==null||pv.getValue()==null||pv.getValue().equals("")){
            System.out.println("参数有误！");
            return;
        }
        String sql = "insert into shop.propertyvalue(pid,ptid,value) values (?,?)";
        try(
                Connection connection = connectionPool.getConnection();
                PreparedStatement ps = connection.prepareStatement(sql)){
            ps.setInt(1,pv.getProduct().getPid());
            ps.setInt(2,pv.getProperty().getProId());
            ps.setString(3,pv.getValue());
            ps.execute();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public void changePropertyValue(PropertyValue pv){
        if(pv==null||pv.getValue()==null||pv.getValue().equals("")){
            System.out.println("参数有误！");
            return;
        }
        String sql = "update shop.propertyvalue set value=? where id = ?,pid=? and ptid=? ";
        try(
                Connection connection = connectionPool.getConnection();
                PreparedStatement ps = connection.prepareStatement(sql)){
            ps.setString(1,pv.getValue());
            ps.setInt(2,pv.getPvId());
            ps.setInt(2,pv.getProduct().getPid());
            ps.setInt(2,pv.getProperty().getProId());
            ps.execute();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public void deletePropertyValue(PropertyValue pv){
        if(pv==null||pv.getValue()==null||pv.getValue().equals("")){
            System.out.println("参数有误！");
            return;
        }
        String sql = "delete from shop.productvalue where id = ?";
        try(
                Connection connection = connectionPool.getConnection();
                PreparedStatement ps = connection.prepareStatement(sql)){
            ps.setInt(1,pv.getPvId());
            ps.execute();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public void OrderDelivery(Order order){
        System.out.println("订单发货");
    }
    public void OrderUnDelivery(Order order){
        System.out.println("订单退货");
    }


}
