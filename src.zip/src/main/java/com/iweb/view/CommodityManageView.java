package com.iweb.view;

import java.util.Scanner;

/**
 * @author jxy
 * @date
 */
public class CommodityManageView {
    public void view(){
        System.out.println("请做出您的选择：");
        System.out.println("1.添加商品");
        System.out.println("2.修改商品");
        System.out.println("3.移除商品");
        Scanner sc = new Scanner(System.in);
        int choice = sc.nextInt();
        switch (choice) {
            case 1:

                break;
            case 2:

                break;
            case 3:

                break;

            default:
                System.out.println("输入有误请重新输入！");
        }
    }
}
