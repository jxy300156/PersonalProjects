package com.iweb.view;

import java.util.Scanner;

/**
 * @author jxy
 * @date
 */
public class OrderManageView {
    public void view(){
        System.out.println("请做出您的选择：");
        System.out.println("1.订单发货");
        System.out.println("2.订单退货");
        Scanner sc = new Scanner(System.in);
        int choice = sc.nextInt();
        switch (choice) {
            case 1:

                break;
            case 2:

                break;
            default:
                System.out.println("输入有误请重新输入！");
        }
    }
}
