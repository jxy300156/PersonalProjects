package com.iweb;

import com.iweb.view.InitialView;

/**
 * @author jxy
 * @date
 */
public class test1 {
    public static void main(String[] args) {
        InitialView initialView = new InitialView();
        initialView.view();
    }
}
